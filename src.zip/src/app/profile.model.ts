export class ProfileModel {
    constructor(public email: string, 
        public password: string, 
        public full_name: string) {}
}